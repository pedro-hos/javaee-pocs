package com.redhat;

import io.quarkus.test.junit.SubstrateTest;

@SubstrateTest
public class NativeExampleResourceIT extends ExampleResourceTest {

    // Execute the same tests but in native mode.
}